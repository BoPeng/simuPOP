#!/usr/bin/env python

'''
 This file demonstrate the use of homoMating, using a parent choosr that
 choose a female that is geographically closest to a random male. A hybrid
 parent chooser pyParentsChooser is used, which will call a Python
 generator function repeatedly to get parents.

 Such hybrid- and pure- Python operators and mating schemes provide a
 very powerful and flexible interface to implement customized genetic effects
 and mating schemes. However, because these functions are implemented in Python,
 they can significantly reduce the performance of your simuPOP script if complex
 algorithms are involved, especially when the Python functions are called
 repeatedly. This problem can be addressed by implementing these functions in
 C++.

 This example demonstrates how to implement some functions in C++, and wrap
 them so that they can be imported into python. This is basically how simuPOP
 is written, and is an important technique to improve the efficiency of
 your simuPOP scripts.

 Several files are involved in this process:
 1. This python file that import the C++ module.
 2. .h and/or .cpp files to re-impmenent the most time-consuming parts in C++.
 3. An interface file cppParentChooser.i, which tells an automatic wrapper
    generating program SWIG how to wrap the code.

 To compile and load functions defined in this interface file, you will need
 to:

 1. download and install SWIG.

 2. Build and install module cppParentChooser by running

	> python setup.py install

    For a previous version of Python (<2.4), you may need to pass swig options
    using command line:

    > python setup.py build_ext --swig-opts='-O -templatereduce -shadow -c++ -keyword -nodefaultctor' install

 3.	You can then try to import your module using

	> python -c 'import cppParentChooser'

Date: 2009-01-11
'''


from simuPOP import *
from random import normalvariate, randint

# if a python module rpy is available, use R to plot the location
# of all individuals.
from simuPOP.plotter import ScatterPlotter

# try to load a more efficient version of parentsChooser, which is defined in
# Mating_homoMating_cpp.h and .i. This file must be compiled to a Python-lodablebe
# module to be imported into this script.
try:
    from cppParentChooser import *
    has_cpp_chooser = True
except:
    print "Module Mating_homoMating_cpp_cpp can not be loaded"
    print "The python version will be used"
    has_cpp_chooser = False


def locOffspring(x, y):
    '''set offspring loc from parental locs'''
    #
    # move to (dad_x + mom_x)/2 + N(0, 1), (dad_y + mom_y)/2 + N(0,1)
    new_x = (x[0]+y[0])/2. + normalvariate(0, 1)
    new_y = (y[0]+y[1])/2. + normalvariate(0, 1)
    # limit to region [-5, 5] x [-5, 5]
    new_x = min(new_x, 5)
    new_x = max(new_x, -5)
    new_y = min(new_y, 5)
    new_y = max(new_y, -5)
    return (new_x, new_y)


def parentsChooser(pop, sp):
    '''Choose parents according to their locations. Because this is only a
       demonstration, performance is not under consideration.
    '''
    males = [ind for ind in pop.individuals(sp) if ind.sex() == MALE]
    females = [ind for ind in pop.individuals(sp) if ind.sex() == FEMALE]
    ################### The C++ version ############
    if has_cpp_chooser:
        # create an object with needed information ...
        pc = parentsChooser_cpp(
            [ind.x for x in males],
            [ind.y for x in males],
            [ind.x for x in females],
            [ind.y for x in females],
            randint(0, 1e8))
        while True:
            # and return indexes of parents
            m, f = pc.chooseParents()
            yield males[m], females[f]
    ##################### The Python version ###############
    if len(males) == 0 or len(females) == 0:
        print 'Lacking male or female. Existing'
        yield (None, None)
    while True:
        # randomly choose a male
        male = males[randint(0, len(males)-1)]
        # choose its closest female
        diff_x = [ind.x - male.x for x in females]
        diff_y = [ind.y - male.y for x in females]
        dist = [x*x + y*y for x,y in zip(diff_x, diff_y)]
        female = females[dist.index(min(dist))]
        #print male, female
        yield (male, female)


def simuGeoMating(size, gen):
    '''
    size  population size
    gen   number of generations to run
    '''
    pop = Population(size, loci=[1], infoFields=['x', 'y'])
    pop.evolve(
        initOps = [
            InitSex(),
            InitGenotype(freq=[0.5, 0.5])
        ],
        matingScheme = HomoMating(PyParentsChooser(parentsChooser), 
            OffspringGenerator(ops=[
                MendelianGenoTransmitter(),
                PyTagger(func=locOffspring)])),
        postOps = [
            PyEval(r'"%s\n" % gen'),
            ScatterPlotter(infoFields=['x', 'y']),
        ],
        gen = gen
    )

if __name__ == '__main__':
    simuGeoMating(1000, 4)

